

export default function AgeMinor(){

    return(

        <div className="div_explanation">
            <h1>We are sorry but minors can not participate in the project. <span>&#9785;</span></h1>
            <p>
            Please, <span>uninstall the extension</span>.
            </p>
            <p>
            Thanks for your interest!
            </p>
        </div>
    )
}