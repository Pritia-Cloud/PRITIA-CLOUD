import json
import logging
from pathlib import Path
import os
import joblib
import numpy as np
import pandas as pd
from collections import Counter
from itertools import chain
from sklearn.preprocessing import MinMaxScaler,OneHotEncoder


def collect_raw_data(CONF_LIST):
    raw_data_dir = CONF_LIST['save_dirs']['raw_data_dir']
    print(raw_data_dir,"-->",list(raw_data_dir.rglob('*.csv')))
    list_dfs = []
    for file_path in raw_data_dir.rglob('*.csv'):
        df = pd.read_csv(file_path)
        print(df.shape)
        list_dfs.append(df)
    final_df = pd.concat(list_dfs)

    return final_df
        
def preprocess_df_1(df):
    FIELDS_TO_REMOVE = ['usedJSHeapSize', 'jsHeapSizeLimit', 'totalJSHeapSize','event_size']
    BANNED_KEYWORDS = "timestamp","region","run_id","uuid","project_name","country","on_cloud","url","os","model","version","tracking"
    df = remove_extra_fields(df,FIELDS_TO_REMOVE,BANNED_KEYWORDS)
    print("PREFILLNA",df.shape)
    #df.isnull().to_csv("test-preprocess.csv")
    df = df.dropna(axis=0,subset=set(
        set(df.columns) - set(["load_cloud_provider",
                               "load_gpu_count",
                               "video_cloud_provider",
                               "video_gpu_count"])
    ))#Adjust if needed, if exist rows with 
    print("POSTFILLNA",df.shape)
    df = fillna_dropna(df)
    df["cleaned_entries"] = df["entries"].apply(lambda x:treat_entries(x))
    df["cleaned_performance"] = df["performance"].apply(lambda x:treat_performance(x))
    df.drop(["entries","performance"],axis=1,inplace=True)
    df = get_common_keys(df,"cleaned_entries")
    df = get_common_keys(df,"cleaned_performance")
    df_entries = pd.DataFrame(list(df["cleaned_entries"].apply(lambda x:json.loads(x)).values))
    df_performance = pd.DataFrame(list(df["cleaned_performance"].apply(lambda x:json.loads(x)).values))
    df.drop(["cleaned_entries", "cleaned_performance"],axis=1,inplace=True)
    df.reset_index(inplace=True)
    df.drop("index",axis=1,inplace=True)
    df = pd.concat([df, df_entries,df_performance], axis=1)
    #Erase columns with a single index not NaN
    df.drop(df.describe().loc["std"].loc[lambda x: x == 0].index,axis=1,inplace=True)
    for col in df.columns:
    #Erase the columns with all none values
        if df.isnull().sum().loc[col] == df.shape[0]:
            df = df.drop(col,axis=1)
    return df
    



def remove_extra_fields(df,fields_to_remove,banned_keywords):
    df = df.drop(fields_to_remove,axis=1)
    banned_cols = [col for col in df.columns  for word in banned_keywords if word in col]
    return df.drop(banned_cols,axis=1)



def load_ad_json(results_dir):
    for path,_,files in os.walk(results_dir):
        for file in files:
            if not file.startswith('.'):
                file_path = os.path.join(path,file)

                with open(file_path) as f:
                    yield json.load(f)


def get_common_keys(df,col):
    df[col] = df[col].apply(lambda x: json.loads(x))
    common_keys =  set.intersection(*[set(entry.keys()) for entry in df[col]])
    df[col] = df[col].apply(lambda x: json.dumps({k:v for k,v in x.items() if k in common_keys})) 
    return df 


def treat_entries(json_entries):
    entries = json.loads(json_entries)
    unpacked_dict = {}
    # Find the longest list of keys
    longest_keys = set.union(*[set(entry.keys()) for entry in entries]) 
    longest_keys.remove("name")

    for k in longest_keys:
        arr = [entries[i].get(k,"UNK") for i in range(len(entries))] 

        arr,most_common_type = get_type_columns(arr)
        arr = [el for el in arr if el!="UNK"]
        if most_common_type == str:
            cat_count = Counter(arr)
            cat_dict = {("res_"+k):v for k,v in dict(cat_count).items()}
            unpacked_dict = {**unpacked_dict,**cat_dict} 

        if most_common_type == float or most_common_type == int:
            cont_dict = {"entries_avg_"+k:np.average(arr),
                        "entries_median_"+k:np.median(arr),
                        "entries_min_"+k:np.min(arr),
                        "entries_max_"+k:np.max(arr),
                        "entries_range_"+k:np.ptp(arr),
                        "entries_std_"+k:np.std(arr)}
            unpacked_dict = {**unpacked_dict,**cont_dict}


    return json.dumps(unpacked_dict)

def get_type_columns(arr):
    arr = [float(i) if isinstance(i,int) else i for i in arr]
    counter_types = Counter(type(i) for i in arr if i!="UNK")
    if len(counter_types) != 1:
        print(counter_types)
        raise ValueError("The number of counter types should be 1")
    return arr,counter_types.most_common(1)[0][0]

def treat_performance(json_perf):
    performance = json.loads(json_perf)
    any_dict = any([isinstance(v,dict) for v in performance.values()])
    while any_dict:
        for k,v in performance.items():
            if isinstance(v,dict):
                v_unpacked = {str(k)+"_"+k1:v1 for k1,v1  in v.items()}
                performance = {**performance,**v_unpacked}
                del performance[k]
        any_dict = any([isinstance(v,dict) for v in performance.values()])
    return json.dumps(performance)

def treat_dict(test_ad):

    for k in {key for key,val in test_ad.items() if type(val) == dict}:
        treated = {str(k)+"_"+k1:v1 for k1,v1  in test_ad[k].items()}
        test_ad = {**test_ad,**treated}
        del test_ad[k]
    return test_ad


def create_dataframe(results_dir):
    ads_dict = []
    for test_ad in load_ad_json(results_dir):
        test_ad = remove_extra_fields(test_ad)
        #skip blank
        if test_ad["uuid"] == "blank":
            continue

        #test_ad = treat_entries(test_ad)
        #test_ad = treat_dict(test_ad)
        ads_dict.append(test_ad) 

    return pd.DataFrame(ads_dict)

def expand_dicts(df_ads):
    new_df = []
    for index,row in df_ads.iterrows():
        dict_row = dict(row)
        row = treat_entries(dict_row)
        row = treat_dict(row)
            
        new_df.append(row)

    new_df = pd.DataFrame(new_df)

    return new_df

def preprocess_df(df_ads):
    #Erase columns with a single index not NaN
    df_ads = df_ads.drop(df_ads.describe().loc["std"].loc[lambda x: x == 0].index,axis=1)
    #Drop columns with all None values
    for col in df_ads.columns:
    #Erase the columns with all none values
        if df_ads.isnull().sum().loc[col] == df_ads.shape[0]:
            df_ads = df_ads.drop(col,axis=1)
    #Erase useless columns 
    banned_keywords = "timestamp","region","run_id","uuid","project_name","country","on_cloud","url","os","model","version","tracking"
    banned_cols = [col for col in df_ads.columns  for word in banned_keywords if word in col]
    df_ads = df_ads.drop(banned_cols,axis=1)
    #Filling NaN values of perf.getEntries
    
    #df_ads.fillna(0,inplace=True)
    #Add column corresponding to substraction of energy consumption
    #df_ads["energy_consumed_ad"] = df_ads["energy_consumed"] - df_ads["driver_baseline_energy_consumed"]

    return df_ads 

def create_target_variable(df,conf_list):
    if conf_list["ads_with_duration"]:
        df[conf_list["target_variable"]] = df["load_energy_consumed"] - df["baseline_load_mean_energy_consumed"] + df["video_energy_consumed"] - df["baseline_video_mean_energy_consumed"]*df["video_duration"]
    else:
        df[conf_list["target_variable"]] = df["energy_consumed"] - df["baseline_mean_energy_consumed"]

    return df

def select_cat_cols(df_ads):
    return list(df_ads.dtypes.loc[lambda x: x == object].index)

def select_non_cat_cols(df_ads):
    return list(set(df_ads.columns) - set(select_cat_cols(df_ads)))


def encode_cat_cols(df,cat_cols):
    encoder = OneHotEncoder(sparse_output=False).set_output(transform="pandas")
    cols_encoded = encoder.fit_transform(df[cat_cols])
    df = df.drop(cat_cols,axis=1)
    return pd.concat([df,cols_encoded],axis=1)


def remove_outliers(df,col,factor=1.5):
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    limite_inferior = Q1 - factor * IQR
    limite_superior = Q3 + factor * IQR
    df_filtrado = df[(df[col] >= limite_inferior) & (df[col] <= limite_superior)].dropna()
    return df_filtrado


def erase_correlated_cols(df_ads, target_cols, threshold, preferential_col):
    corr_matrix = df_ads.corr().abs()
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
    to_drop = []

    for column in target_cols:
        if column == preferential_col:
            continue  # No se elimina la columna preferencial

        correlated_cols = upper[column][upper[column] > threshold].index.tolist()
        if correlated_cols:
            to_drop.append(column)  # Eliminar solo una de las columnas correlacionadas

    df_ads.drop(to_drop, axis=1, inplace=True)
    return df_ads

def encode_categorical_cols(df):

    cat_cols = select_cat_cols(df)
    print("CAT COLS",cat_cols)
    df = encode_cat_cols(df,cat_cols)

    non_cat_cols = select_non_cat_cols(df)
    return df,cat_cols,non_cat_cols

def erase_correlated_and_outliers(df,conf_list,non_cat_cols,corr_threshold=0.95):
    df = remove_outliers(df,conf_list["target_variable"])
    df = erase_correlated_cols(df,non_cat_cols,corr_threshold,conf_list["target_variable"])

    return df


def scale(df_ads,cols_to_scale):
    df_ads = df_ads[cols_to_scale]
    sc = MinMaxScaler()
    df_standarized = pd.DataFrame(sc.fit_transform(df_ads),columns=df_ads.columns)
    return sc,df_standarized

def contain_substring(word, banned_substrings):
    for subcadena in banned_substrings:
        if subcadena in word:
            return True
    return False

def classify_cols(df_ads):

    banned_keywords = ["baseline","timeOrigin"]
    label_keywords = ["load","video","energy","emissions"]
    non_study_cols = [col for col in df_ads.columns if contain_substring(col,banned_keywords)]

    #exceptions = [item for item in non_study_cols if "duration" in item and "entries" in item ]
    #non_study_cols = [item for item in non_study_cols if item not in exceptions]
    labels = [col for col in df_ads.columns if contain_substring(col,label_keywords)]
    study_cols = list(set(df_ads.columns) - set(non_study_cols) - set(labels))

    
    return non_study_cols,study_cols,labels

    

def save(df_ads,OUTPUT_FILENAME):
    df_ads.to_csv(OUTPUT_FILENAME,index=False)


def generate_dataset(df_ads,class_cols,CONF_LIST):
    save_path = CONF_LIST["save_dirs"]["clean_data_dir"].joinpath(CONF_LIST["name"])
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    for i,name in enumerate(["DataX","DataY"]):
        save(df_ads[[col for col in df_ads.columns if col in class_cols[i+1]]],str(save_path)+f"/{name}.csv")

def fillna_dropna(df, threshold=0.25, fill_value="Unknown"):
    """
    Fill NaNs with 'Unknown' for string columns with up to 25% NaNs
    and fill NaNs with mean for other columns with up to 25% NaNs.
    Drop columns with more than 25% NaNs.

    Parameters:
    - df: DataFrame
    - threshold: Threshold to decide whether to fill or drop columns (default is 0.25)
    - fill_value: Value to fill NaNs in string columns (default is 'Unknown')

    Returns:
    - df: Modified DataFrame
    """

    if df.isnull().sum().sum() == 0:
        return df

    # Identify columns with string dtype
    string_columns = df.select_dtypes(include=['object']).columns

    # Calculate the proportion of NaNs per column
    nan_proportions = (df.isnull().sum() / len(df)).sort_values()

    # Filter columns to fill or drop
    columns_to_fill = nan_proportions[nan_proportions <= threshold].index
    columns_to_drop = nan_proportions[nan_proportions > threshold].index
    # print("COLUMNS TO FILL")
    # print(columns_to_fill)
    # print("COLUMNS TO DROP")
    # print(columns_to_drop)

    # Fill NaNs with 'Unknown' for selected string columns
    # Fill NaNs with mean for other columns
    for column in columns_to_fill:
        if column in string_columns:
            df[column] = df[column].fillna(fill_value)
        else:
            df[column] = df[column].fillna(df[column].mean())

    # Drop columns with more than 25% NaNs
    df = df.drop(columns=columns_to_drop)

    return df

def save_scaling_features(scaler,features,scaling_features,CONF_LIST):
    save_path = CONF_LIST["save_dirs"]["model_dir"].joinpath(CONF_LIST["name"],"scaler")
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    joblib.dump(scaler, save_path.joinpath('scaler.joblib'))
    with open(save_path.joinpath('selected_features.json'), 'w') as json_file:
            json.dump(features, json_file)
    with open(save_path.joinpath('scaling_features.json'), 'w') as json_file:
            json.dump(scaling_features, json_file)


def scale_and_save(df,conf_list):
    class_cols = classify_cols(df)
    scaling_features = list(chain(*class_cols[1:]))
    scaler,df = scale(df,scaling_features)
    generate_dataset(df,class_cols,conf_list)
    save_scaling_features(scaler,class_cols[1],scaling_features,conf_list)


#--------------------------------------
        
def clean_data(CONF_LIST):
    #Collect data
    raw_data_df = collect_raw_data(CONF_LIST)
    #Clean dataframe
    df_preprocessed = preprocess_df_1(raw_data_df)
    #Create target variable
    df_preprocessed = create_target_variable(df_preprocessed,CONF_LIST)
    for item in df_preprocessed.dtypes:
        print(item)
    #Select and encode categorical columns
    df_preprocessed,cat_cols,non_cat_cols = encode_categorical_cols(df_preprocessed)
    #Remove outliers and erase correlated columns
    df_preprocessed = erase_correlated_and_outliers(df_preprocessed,CONF_LIST,non_cat_cols)
    #Scale and save data
    scale_and_save(df_preprocessed,CONF_LIST)


    # cat_cols = select_cat_cols(df_final)
    # df_final = encode_cat_cols(df_final,cat_cols)
    # non_cat_cols = select_non_cat_cols(df_final)
    # df_final = remove_outliers(df_final,CONF_LIST["target_variable"])
    
    # df_final = erase_correlated_cols(df_final,non_cat_cols,0.95,CONF_LIST["target_variable"])
    # class_cols = classify_cols(df_final)
    # scaling_features = list(chain(*class_cols[1:]))
    # scaler,df_final = scale(df_final,scaling_features)
    # generate_dataset(df_final,class_cols,CONF_LIST)
    # save_scaling_features(scaler,class_cols[1],scaling_features,CONF_LIST)


def clean_to_predict(df_final,model_directory):
    """
    Data path is the directory of .html files
    """
    # json_files = os.listdir(data_path)
    # dfs = []
    # for json_file in json_files:
    #     with open(json_file, 'r') as file:
    #         data = pd.read_json(file)
    #         dfs.append(data)
    # #Loading features and scaler to be applied
    # df_final = pd.concat(dfs, ignore_index=True)
    file_features = model_directory.joinpath("selected_features.json")
    file_scaler = model_directory.joinpath("scaler.joblib")
    file_headers = model_directory.joinpath("scaling_features.json")
    with open(file_features,'r') as f1,open(file_scaler,'rb') as f2, open(file_headers,'r') as f3:
        features = json.load(f1)
        scaler = joblib.load(f2) 
        scaling_features = json.load(f3)
    df_final.fillna(0,inplace=True)
    cat_cols = select_cat_cols(df_final)
    df_final = encode_cat_cols(df_final,cat_cols)
    df_final = fillna_dropna(df_final)
    try:
        df_final = df_final[features]
    except KeyError as e:
        str_traceback = str(e)
        # print("KEYERROR OBTAINED: THE FOLLOWING VARIABLES ARE MISSING")
        # print("THEY WILL BE FILLED AS ZEROS. PLEASE, SELECT THE VARIABLE")
        # print(str_traceback.split("'"))
        # index_from_traceback = int(input("Select index from tuple:"))
        df_final[str_traceback.split("'")[1:-1]] = 0
    #COLUMNS THAT ARE IN THE DF BUT NOT IN SCALING FEATURES 
    cols_to_drop = set(df_final.columns) - set(scaling_features)
    #COLUMNS THAT ARE IN SCALING FEATURES BUT NOT IN THE DF
    cols_to_fill =  set(scaling_features) - set(df_final.columns)
    
    # all_headers = []
    # for file in ("DataX.csv","DataY.csv"):
    #     headers = pd.read_csv(model_directory.joinpath(file), nrows=1).columns.tolist()
    #     all_headers += headers
    # print("COLUMNS THAT WE ARE INTRODUCING AS REFILL")
    # cols_refill = set(all_headers) - set(df_final.columns)
    # cols_erase = set(df_final.columns) - set(all_headers)
    df_final.drop(cols_to_drop,axis=1,inplace=True)
    for col in cols_to_fill:
        df_final[col] = 0

    df_final = df_final[scaling_features]
    #To prepare the final vector, find where are our actual features
    where_features = [scaling_features.index(item) for item in features]
    print(where_features)
    print("DO WE HAVE SAME FEATURES",set(df_final.columns) == set(scaling_features))
    print("PERFORM SCALING")
    df_final = scaler.transform(df_final)

    return df_final[:,where_features]








  