
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score


def train_rf(X_train,X_test,y_train,y_test,params):
    # Crea un modelo de Random Forest para regresión
    rf_regressor = RandomForestRegressor(        
        n_estimators=params["n_estimators"],
        max_depth=params["max_depth"],
        min_samples_split=params["min_samples_split"],
        min_samples_leaf=params["min_samples_leaf"])
    # Entrena el modelo en el conjunto de entrenamiento
    rf_regressor.fit(X_train, y_train)
    # Realiza predicciones en el conjunto de prueba
    y_pred = rf_regressor.predict(X_test)
    
    return rf_regressor,y_test,y_pred 

def train_rf_study(X_train,X_test,y_train,y_test,trial):

    # Definir hiperparámetros para el modelo Random Forest
    n_estimators = trial.suggest_int('n_estimators', 5, 100)
    max_depth = trial.suggest_int('max_depth', 2, 128, log=True)
    min_samples_split = trial.suggest_int('min_samples_split', 2, 10)
    min_samples_leaf = trial.suggest_int('min_samples_leaf', 1, 5)

    # Crear el modelo Random Forest con los hiperparámetros sugeridos
    model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_split=min_samples_split,
        min_samples_leaf=min_samples_leaf,
        random_state=42
    )

    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    r2 = r2_score(y_test, y_pred)

    return r2