from sklearn.metrics import mean_absolute_error, mean_squared_error,r2_score
import xgboost as xgb

def train_xgb(X_train,X_test,y_train,y_test,params):
    model_xgb = xgb.XGBRegressor(**params)
    model_xgb.fit(X_train.values,y_train.values)

    return model_xgb,y_test,model_xgb.predict(X_test)

def train_xgb_study(X_train,X_test,y_train,y_test,trial):
        params = {
        "objective": "reg:squarederror",
        "n_estimators": 1000,
        "verbosity": 0,
        "eta": trial.suggest_float("eta", 1e-9, 0.1, log=True),
        "max_depth": trial.suggest_int("max_depth", 1, 10),
        "subsample": trial.suggest_float("subsample", 0.05, 1.0),
        "colsample_bytree": trial.suggest_float("colsample_bytree", 0.05, 1.0),
        "min_child_weight": trial.suggest_int("min_child_weight", 1, 20),}

        model = xgb.XGBRFRegressor(**params)

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        r2 = r2_score(y_test, y_pred)

        return r2