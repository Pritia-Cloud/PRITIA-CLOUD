
import json
import os
from pathlib import Path
import joblib
import optuna
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import ElasticNet, Lasso, LinearRegression, Ridge
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.model_selection import train_test_split
import torch
from xgboost import XGBRegressor

from .models.xgb import train_xgb, train_xgb_study
from .models.svr import train_svr
from .models.rf import train_rf, train_rf_study
from .models.nn import train_nn, train_nn_study



def _evaluate_regression(x_true, x_pred, model,model_instance, CONF_LIST):
    """
    Evaluate the performance of a regression model and save the results in a JSON file.

    Parameters:
    - x_true: True values (ground truth)
    - x_pred: Predicted values from the regression model
    - model: Name or identifier of the regression model
    - model_instance: Model object to be saved
    - save_directory: Directory to save the results

    Returns:
    - results_dict: Dictionary containing metrics and their values
    """
    # Calculate metrics
    mse = mean_squared_error(x_true, x_pred)
    r2 = r2_score(x_true, x_pred)

    # Create a dictionary with results
    results_dict = {
        'mse': mse,
        'r_2': r2
    }

    # Check if the JSON file exists
    save_directory = CONF_LIST["save_dirs"]["model_dir"].joinpath(CONF_LIST["name"],"best_model")
    results_path = os.path.join(save_directory,'results.json')
    if os.path.exists(results_path):
        # Load existing results from the JSON file
        with open(results_path, 'r') as json_file:
            existing_results = json.load(json_file)
        
        # Compare the existing R^2 with the new one
        existing_r2 = existing_results.get('r_2', float('-inf'))
        if r2 > existing_r2:
            delete_files(save_directory)
            # Save the new results in the JSON file
            with open(results_path, 'w') as json_file:
                json.dump(results_dict, json_file, indent=4)
            
            # Save the model instance based on its type
            _save_model_to_file(model_instance, os.path.join(save_directory,model))

            print(f'New results saved in JSON format at: {results_path}')
            print(f'New model instance saved.')
        else:
            print("We have a better model for this method")

    else:
        # Save the results in a new JSON file
        if not os.path.exists(save_directory):
            os.makedirs(save_directory)
        with open(results_path, 'w') as json_file:
            json.dump(results_dict, json_file, indent=4)
        # Save the model instance based on its type
        _save_model_to_file(model_instance, os.path.join(save_directory,model))

    return results_dict

def _save_model_to_file(model, file_name):
    """
    Save a regression model, XGBRegressor, RandomForestRegressor, or PyTorch model based on the instance type.

    Parameters:
    - model: The regression model, XGBRegressor, RandomForestRegressor, or PyTorch model instance
    - file_path: Path to save the model

    Returns:
    - None
    """
    if isinstance(model, (LinearRegression, Ridge, Lasso, ElasticNet, RandomForestRegressor)):
        # Save scikit-learn regression model or RandomForestRegressor
        joblib.dump({'model': model},f"{file_name}.sav")
    elif isinstance(model, XGBRegressor):
        booster = model.get_booster()
        booster.save_model(file_name + "_xgb.json")
    elif isinstance(model, torch.nn.Module):
        # Save PyTorch model
        torch.save(model.state_dict(), file_name+".pt")
    else:
        raise ValueError("Unsupported model type. Please provide a supported regression, XGBRegressor, RandomForestRegressor, or PyTorch model.")


def _train_test_split(CONF_LIST):
    """
    Given the tree of directories, produce train and test split with those data
    """
    
    data_x = pd.read_csv(CONF_LIST["save_dirs"]["clean_data_dir"].joinpath(CONF_LIST["name"],"DATAX.csv"))
    data_y = pd.read_csv(CONF_LIST["save_dirs"]["clean_data_dir"].joinpath(CONF_LIST["name"],"DATAY.csv"))
    data_y = data_y[CONF_LIST["target_variable"]]


    X_train, X_test, y_train, y_test = train_test_split(data_x, data_y, test_size=0.2, random_state=42)

    return X_train,X_test,y_train,y_test



def train_model(CONF_LIST,model):

    N_TRIALS = 1000

    X_train,X_test,y_train,y_test = _train_test_split(CONF_LIST)


    if model == "rf":
        study = optuna.create_study(direction='maximize')  
        study.optimize(lambda trial: train_rf_study(X_train, X_test, y_train, y_test, trial), n_trials=N_TRIALS)
        _model,y_test,y_pred = train_rf(X_train,X_test,y_train,y_test,study.best_params)
    if model == "nn":
        study = optuna.create_study(direction='maximize')  
        study.optimize(lambda trial: train_nn_study(X_train, X_test, y_train, y_test, trial), n_trials=N_TRIALS)
        _model, y_test,y_pred  = train_nn(X_train, X_test, y_train, y_test, study.best_params)

    if model == "svr":
         _model,y_test,y_pred = train_svr(X_train,X_test,y_train,y_test)
    if model == "xgb":
        study = optuna.create_study(direction='maximize')  
        study.optimize(lambda trial: train_xgb_study(X_train, X_test, y_train, y_test, trial), n_trials=N_TRIALS)
        _model,y_test,y_pred = train_xgb(X_train,X_test,y_train,y_test,study.best_params)


    _evaluate_regression(y_test,y_pred,model,_model,CONF_LIST)
    

       

def delete_files(directory):
    for filename in os.listdir(directory): 
        filepath = os.path.join(directory, filename)
        try:
            if os.path.isfile(filepath):
                os.unlink(filepath)
        except Exception as e:
                print(f"Error deleting {filename}: {e}")
