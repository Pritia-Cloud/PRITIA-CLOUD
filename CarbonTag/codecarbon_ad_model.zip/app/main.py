import os
from utils.utils import version_data
from cleaning.organize_data import clean_data
from model.train import train_model
from pathlib import Path


def main(model="rf"):

    # version_data()
    # sys.exit()
    CONF_LIST = {
            "name":"facebook",
            "save_dirs":{
                "raw_data_dir":Path.cwd().joinpath("downloaded_data/facebook-video"),
                "clean_data_dir":Path.cwd().joinpath("clean_data_facebook-video"),
                "model_dir":Path.cwd().joinpath("model"),
            },
            "list_devices":"",#"home_ubuntu_3","home_windows_2","home_windows_4","laptop_mac","laptop_ubuntu","laptop_windows"],
            "list_modes":"",
            "target_variable":"energy_consumed_ad",
    }

    for dir in CONF_LIST["save_dirs"].values():
        if not os.path.exists(dir):
            os.makedirs(dir)
    

    #If we have clean data for an experiment, do not clean again
    exists_scaler_dir =  os.path.exists(CONF_LIST["save_dirs"]["model_dir"].joinpath(CONF_LIST["name"],"scaler"))
    exists_clean_data_dir = os.path.exists(CONF_LIST["save_dirs"]["clean_data_dir"].joinpath(CONF_LIST["name"]))
    if not(exists_clean_data_dir) or not(exists_scaler_dir):
        clean_data(CONF_LIST)

    train_model(CONF_LIST,model=model)


if __name__ == "__main__":
    main(model="rf")