from pathlib import Path
from subprocess import CalledProcessError
import subprocess



def run_shell_command(cmd: str) -> str:
    return subprocess.run(cmd, text=True, shell=True, check=True, capture_output=True).stdout



def is_dvc_initialized() -> bool:
    return (Path.cwd() / ".dvc").exists()


def initialize_dvc() -> None:
    if is_dvc_initialized():
        print("DVC is already initialized")
        return
    print("Initializing DVC")
    run_shell_command("dvc init")
    run_shell_command("dvc config core.analytics false")
    run_shell_command("dvc config core.autostage true")
    run_shell_command("git add .dvc")
    run_shell_command("git commit -m 'Initialized dvc'")


def initialize_dvc_storage(dvc_remote_name: str, dvc_remote_url: str) -> None:
    if not (run_shell_command("dvc remote list")):
        print("Initializing DVC storage")
        run_shell_command(f"dvc remote add -d {dvc_remote_name} {dvc_remote_url}")
        run_shell_command("git add .dvc/config")
        run_shell_command(f"git commit -m 'Configured remote storage at: {dvc_remote_url}'")
    else:
        print("DVC storage was already initialized")


def commit_to_dvc(dvc_raw_data_folder: str, dvc_remote_name: str) -> None:
    current_version = run_shell_command("git tag --list | sort -t v -k 2 -g | tail -1 | sed 's/v//'").strip()
    if not current_version:
        current_version = "0"
    next_version = f"v{int(current_version)+1}"
    run_shell_command(f"dvc add {dvc_raw_data_folder}")
    run_shell_command("git add .")
    run_shell_command(f"git commit -m 'Update data from v{current_version} to {next_version}' ")
    run_shell_command(f"git tag -a {next_version} -m 'Data version {next_version}'")
    run_shell_command(f"dvc push {dvc_raw_data_folder}.dvc --remote {dvc_remote_name}")
    run_shell_command("git push --set-upstream --follow-tags origin main ")
    run_shell_command("git push -f --tags")


def make_new_data_version(dvc_raw_data_folder: str, dvc_remote_name: str) -> None:
    try:
        status = run_shell_command(f"dvc status {dvc_raw_data_folder}.dvc")
        if status == "Data and pipelines are up to date.\n":
            print("Data and pipelines are up to date.")
            return
        else:
            commit_to_dvc(dvc_raw_data_folder, dvc_remote_name)
    except CalledProcessError:
        commit_to_dvc(dvc_raw_data_folder, dvc_remote_name)


def version_data() -> None:
    DVC_REMOTE_NAME = "gdrive-storage"
    DVC_REMOTE_URL =  "gdrive://10ewoSCj26-P39lhBvmRAhYVliONmzX3I"
    DVC_RAW_DATA_FOLDER = "raw_data"


    initialize_dvc()

    initialize_dvc_storage(DVC_REMOTE_NAME, DVC_REMOTE_URL)

    make_new_data_version(DVC_RAW_DATA_FOLDER, DVC_REMOTE_NAME)

