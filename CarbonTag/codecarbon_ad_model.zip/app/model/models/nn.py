

from matplotlib import pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error,r2_score
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader,TensorDataset

def train_nn(X_train,X_test,y_train,y_test,params):
    print("X_TEST_SHAPE",X_test.shape)
    NUM_EPOCHS = 10
    LAYERS = [28,56,128,56,28]
    P_DROPOUT = 0
    LEARNING_RATE = params["lr"]
    BATCH_SIZE = params["batch_size"]
    
    train_dataset = DataLoader(TensorDataset(torch.tensor(X_train.values,dtype=torch.float32),
                                            torch.tensor(y_train.values.reshape(-1,1),dtype=torch.float32)),
                            batch_size=BATCH_SIZE,shuffle=True)
    tensor_X_test = torch.tensor(X_test.values,dtype=torch.float32)
    tensor_y_test = torch.tensor(y_test.values.reshape(-1,1),dtype=torch.float32)


    class Net(nn.Module):

        def __init__(self, n_in, out_sz, layers, p= P_DROPOUT):
            # Inherting from nn.Module the basic functionality
            super().__init__()
            # Normalization layer
            self.bn_cont = nn.BatchNorm1d(n_in)
            
            layerlist = []
            #Each of the building blocks
            for i in layers:
                layerlist.append(nn.Linear(n_in,i)) 
                layerlist.append(nn.ReLU(inplace=True))
                layerlist.append(nn.BatchNorm1d(i))
                layerlist.append(nn.Dropout(p))
                n_in = i
            layerlist.append(nn.Linear(layers[-1],out_sz))

            #Sequential constructon of the NN    
            self.layers = nn.Sequential(*layerlist)
            
        
        def forward(self, x):
            # Applying normalization
            x = self.bn_cont(x)
            #Passing through the layers
            x = self.layers(x)
            return x
        
    model = Net(X_train.shape[1],out_sz=1,layers=LAYERS)
    criterion = nn.MSELoss()  
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)



    loss_hist = []

    for epoch in range(NUM_EPOCHS):
        for inputs, labels in train_dataset:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss_hist.append(float(loss.detach().numpy()))
            loss.backward()
            optimizer.step()

    plot_loss_curve(loss_hist,"train_loss.png")
    # Evaluar el modelo en el conjunto de prueba
    model.eval()
    with torch.no_grad():
        y_pred = model(tensor_X_test)
        test_loss = criterion(y_pred, tensor_y_test)

    print(f"MSE LOSS: {test_loss.item():.3e}")

    _tensor_y_test = tensor_y_test.flatten().detach().numpy()
    _tensor_y_pred = model(tensor_X_test).flatten().detach().numpy()
    # The mean square error
    print("Mean squared error: %.3e" % mean_squared_error(tensor_y_test.flatten().detach().numpy(), 
                                                        model(tensor_X_test).flatten().detach().numpy()))
    # The mean absolute error
    print("Mean absolute error: %.3e" % mean_absolute_error(tensor_y_test.flatten().detach().numpy(), 
                                                            model(tensor_X_test).flatten().detach().numpy()))

    # The coefficient of determination: 1 is perfect prediction
    print("Coefficient of determination: %.6f" % r2_score(tensor_y_test.flatten().detach().numpy(), 
                                                            model(tensor_X_test).flatten().detach().numpy()))
    
    return model,_tensor_y_test,_tensor_y_pred


def plot_loss_curve(losses, save_path=None):
    plt.semilogy(losses, label='Training Loss')
    plt.title('Training Loss Over Epochs')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()

    if save_path:
        plt.savefig(save_path)
        print(f'Figura guardada en: {save_path}')
    else:
        plt.show()


import optuna
from sklearn.metrics import mean_squared_error

def train_nn_study(X_train, X_test, y_train, y_test, trial):
    NUM_EPOCHS = 10
    LAYERS = [28, 56, 128, 56, 28]
    P_DROPOUT = 0
    
    # Obtener hiperparámetros desde el objeto 'trial' de Optuna
    LEARNING_RATE = trial.suggest_float('lr', 1e-5, 1e-1, log=True)
    BATCH_SIZE = trial.suggest_int('batch_size', 8, 128, log=True)

    train_dataset = DataLoader(TensorDataset(torch.tensor(X_train.values, dtype=torch.float32),
                                             torch.tensor(y_train.values.reshape(-1, 1), dtype=torch.float32)),
                               batch_size=BATCH_SIZE, shuffle=True)
    
    tensor_X_test = torch.tensor(X_test.values, dtype=torch.float32)
    tensor_y_test = torch.tensor(y_test.values.reshape(-1, 1), dtype=torch.float32)

    class Net(nn.Module):
        def __init__(self, n_in, out_sz, layers, p=P_DROPOUT):
            super().__init__()
            self.bn_cont = nn.BatchNorm1d(n_in)
            layerlist = []
            for i in layers:
                layerlist.append(nn.Linear(n_in, i))
                layerlist.append(nn.ReLU(inplace=True))
                layerlist.append(nn.BatchNorm1d(i))
                layerlist.append(nn.Dropout(p))
                n_in = i
            layerlist.append(nn.Linear(layers[-1], out_sz))
            self.layers = nn.Sequential(*layerlist)

        def forward(self, x):
            x = self.bn_cont(x)
            x = self.layers(x)
            return x

    model = Net(X_train.shape[1], out_sz=1, layers=LAYERS)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

    loss_hist = []

    for epoch in range(NUM_EPOCHS):
        for inputs, labels in train_dataset:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss_hist.append(float(loss.detach().numpy()))
            loss.backward()
            optimizer.step()

    # Evaluar el modelo en el conjunto de prueba
    model.eval()
    with torch.no_grad():
        y_pred = model(tensor_X_test)
        test_loss = criterion(y_pred, tensor_y_test)
    
    # Devolver la métrica a optimizar (en este caso, el test loss)
    return test_loss.item()

