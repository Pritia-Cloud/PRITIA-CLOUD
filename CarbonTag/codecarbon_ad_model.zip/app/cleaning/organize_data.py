import json
import logging
from pathlib import Path
import os
import joblib
import numpy as np
import pandas as pd
from collections import Counter
from itertools import chain
from sklearn.preprocessing import MinMaxScaler,OneHotEncoder


def remove_extra_fields(json_file):
    fields_to_remove = ['usedJSHeapSize', 'jsHeapSizeLimit', 'totalJSHeapSize','event_size']
    return {k:v for k,v in json_file.items() if k not in fields_to_remove}

def load_ad_json(json_files):
    for file in json_files:
        if not file.name.startswith('.'):
            try:
                with open(file) as f:
                    
                    yield json.load(f)
            except:
                continue


def treat_entries(test_ad):
    common_keys = set.intersection(*[set(entry.keys()) for entry in test_ad["entries"]])
    common_keys.remove("name")
    for k in common_keys:
        arr = [test_ad["entries"][i][k] for i in range(len(test_ad["entries"]))]

        if type(arr[0]) == str:
            cat_count = Counter(arr)
            cat_dict = {("res_"+k):v for k,v in dict(cat_count).items()}
            test_ad = {**test_ad,**cat_dict} 

        if type(arr[0]) == int or type(arr[0]) == float:
            cont_dict = {"entries_avg_"+k:np.average(arr),
                         "entries_median_"+k:np.median(arr),
                         "entries_min_"+k:np.min(arr),
                         "entries_max_"+k:np.max(arr),
                         "entries_range_"+k:np.ptp(arr),
                         "entries_std_"+k:np.std(arr)}
            test_ad = {**test_ad,**cont_dict}
    del test_ad["entries"]
    return test_ad

def treat_dict(test_ad):

    for k in {key for key,val in test_ad.items() if type(val) == dict}:
        treated = {str(k)+"_"+k1:v1 for k1,v1  in test_ad[k].items()}
        test_ad = {**test_ad,**treated}
        del test_ad[k]
    return test_ad


def create_dataframe(results_dir):
    are_jsons = (list(Path(results_dir).rglob("*.json"))) 
    are_csvs = (list(Path(results_dir).rglob("*.csv")))
    ads_dict = [] 
    if are_jsons:
        json_files = Path(results_dir).rglob("*.json")
        for test_ad in load_ad_json(json_files):
            test_ad = remove_extra_fields(test_ad)
            #skip blank
            # if test_ad["uuid"] == "blank":
            #     continue

            #test_ad = treat_entries(test_ad)
            #test_ad = treat_dict(test_ad)
            ads_dict.append(test_ad)
        
        return pd.DataFrame(ads_dict)

    if are_csvs:
        csv_files = Path(results_dir).rglob("*.csv")
        dfs = []
        for file in csv_files:
            test_df = pd.read_csv(file)
            fields_to_remove = ['usedJSHeapSize', 'jsHeapSizeLimit', 'totalJSHeapSize','event_size','UUID']
            test_df.drop(fields_to_remove,axis=1,inplace=True)

            # print(test_df.iloc[0]["entries"],type(test_df.iloc[0]["entries"]))
            # print(json.loads(test_df.iloc[0]["entries"].replace("'",'"')))
            possible_jsons = ["entries","entries_info","timing"]
            for col in possible_jsons:
                if col in test_df.columns:
                    test_df[col] = test_df[col].apply(lambda x: json.loads(x.replace("'",'"')))

            #skip blank
            # if test_ad["uuid"] == "blank":
            #     continue

            #test_ad = treat_entries(test_ad)
            #test_ad = treat_dict(test_ad)
            dfs.append(test_df)
        final_df = pd.concat(dfs,axis=0)


        return final_df
    
    return NotImplementedError

def expand_dicts(df_ads):
    new_df = []
    for index,row in df_ads.iterrows():
        dict_row = dict(row)
        row = treat_entries(dict_row)
        row = treat_dict(row)
            
        new_df.append(row)

    new_df = pd.DataFrame(new_df)

    return new_df

def preprocess_df(df_ads):
    #Erase columns with a single index not NaN
    df_ads = df_ads.drop(df_ads.describe().loc["std"].loc[lambda x: x == 0].index,axis=1)
    #Drop columns with all None values
    for col in df_ads.columns:
    #Erase the columns with all none values
        if df_ads.isnull().sum().loc[col] == df_ads.shape[0]:
            df_ads = df_ads.drop(col,axis=1)
    #Erase useless columns 
    banned_keywords = "timestamp","region","run_id","uuid","project_name","country","on_cloud","model","version","os","navigation","tracking_mode"
    banned_cols = [col for col in df_ads.columns  for word in banned_keywords if word in col]
    df_ads = df_ads.drop(banned_cols,axis=1)
    #Filling NaN values of perf.getEntries
    
    df_ads.fillna(0,inplace=True)
    #Add column corresponding to substraction of energy consumption
    print(df_ads.columns)
    #
    try:
        df_ads["energy_consumed_ad"] = df_ads["energy_consumed"] - df_ads["driver_baseline_energy_consumed"]
    except KeyError:
        #Already been baselined
        df_ads["energy_consumed_ad"] = df_ads["energy_consumed"]
    return df_ads 

def select_cat_cols(df_ads):
    return list(df_ads.dtypes.loc[lambda x: x == object].index)

def select_non_cat_cols(df_ads):
    return list(set(df_ads.columns) - set(select_cat_cols(df_ads)))


def encode_cat_cols(df,cat_cols):
    encoder = OneHotEncoder(sparse_output=False).set_output(transform="pandas")
    cols_encoded = encoder.fit_transform(df[cat_cols])
    df = df.drop(cat_cols,axis=1)
    return pd.concat([df,cols_encoded],axis=1)


def remove_outliers(df,col,factor=1.5):
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    limite_inferior = Q1 - factor * IQR
    limite_superior = Q3 + factor * IQR
    df_filtrado = df[(df[col] >= limite_inferior) & (df[col] <= limite_superior)].dropna()
    return df_filtrado


def erase_correlated_cols(df_ads, target_cols, threshold, preferential_col):
    corr_matrix = df_ads.corr().abs()
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
    to_drop = []

    for column in target_cols:
        if column == preferential_col:
            continue  # No se elimina la columna preferencial

        correlated_cols = upper[column][upper[column] > threshold].index.tolist()
        if correlated_cols:
            to_drop.append(column)  # Eliminar solo una de las columnas correlacionadas

    df_ads.drop(to_drop, axis=1, inplace=True)
    return df_ads



def scale(df_ads,cols_to_scale):
    df_ads = df_ads[cols_to_scale]
    sc = MinMaxScaler()
    df_standarized = pd.DataFrame(sc.fit_transform(df_ads),columns=df_ads.columns)
    return sc,df_standarized

def classify_cols(df_ads):
    features = list(filter(lambda x: "driver_baseline" in x,df_ads.columns))
    features = [item.replace("driver_baseline_","") for item in features]
    non_study_cols = [item for item in df_ads.columns for word in features if word in item]
    exceptions = [item for item in non_study_cols if "duration" in item and "entries" in item ]
    
    non_study_cols = [item for item in non_study_cols if item not in exceptions]
    non_study_cols.append("duration") #TODO : erase duration porque sí 
    non_study_cols.append("timeOrigin")
    labels = [col for col in df_ads.columns if "energy" in col or "emission" in col]
    study_cols = list(set(df_ads.columns) - set(non_study_cols) - set(labels))

    
    return non_study_cols,study_cols,labels

    

def save(df_ads,OUTPUT_FILENAME):
    df_ads.to_csv(OUTPUT_FILENAME,index=False)


def generate_dataset(df_ads,class_cols,CONF_LIST):
    save_path = CONF_LIST["save_dirs"]["clean_data_dir"].joinpath(CONF_LIST["name"])
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    for i,name in enumerate(["DataX","DataY"]):
        save(df_ads[[col for col in df_ads.columns if col in class_cols[i+1]]],str(save_path)+f"/{name}.csv")

def fillna_dropna(df, threshold=0.25, fill_value="Unknown"):
    """
    Fill NaNs with 'Unknown' for string columns with up to 25% NaNs
    and fill NaNs with mean for other columns with up to 25% NaNs.
    Drop columns with more than 25% NaNs.

    Parameters:
    - df: DataFrame
    - threshold: Threshold to decide whether to fill or drop columns (default is 0.25)
    - fill_value: Value to fill NaNs in string columns (default is 'Unknown')

    Returns:
    - df: Modified DataFrame
    """

    if df.isnull().sum().sum() == 0:
        return df

    # Identify columns with string dtype
    string_columns = df.select_dtypes(include=['object']).columns

    # Calculate the proportion of NaNs per column
    nan_proportions = (df.isnull().sum() / len(df)).sort_values()

    # Filter columns to fill or drop
    columns_to_fill = nan_proportions[nan_proportions <= threshold].index
    columns_to_drop = nan_proportions[nan_proportions > threshold].index
    # print("COLUMNS TO FILL")
    # print(columns_to_fill)
    # print("COLUMNS TO DROP")
    # print(columns_to_drop)

    # Fill NaNs with 'Unknown' for selected string columns
    # Fill NaNs with mean for other columns
    for column in columns_to_fill:
        if column in string_columns:
            df[column] = df[column].fillna(fill_value)
        else:
            df[column] = df[column].fillna(df[column].mean())

    # Drop columns with more than 25% NaNs
    df = df.drop(columns=columns_to_drop)

    return df

def save_scaling_features(scaler,features,scaling_features,CONF_LIST):
    save_path = CONF_LIST["save_dirs"]["model_dir"].joinpath(CONF_LIST["name"],"scaler")
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    joblib.dump(scaler, save_path.joinpath('scaler.joblib'))
    with open(save_path.joinpath('selected_features.json'), 'w') as json_file:
            json.dump(features, json_file)
    with open(save_path.joinpath('scaling_features.json'), 'w') as json_file:
            json.dump(scaling_features, json_file)
#--------------------------------------
        
def clean_data(CONF_LIST):
    all_dfs = []
    if CONF_LIST["list_devices"] and CONF_LIST["list_modes"]:
        for device in CONF_LIST["list_devices"]:
            print(f"Cleaning data for device {device}")
            for mode in CONF_LIST["list_modes"]:
                raw_data_dir = CONF_LIST["save_dirs"]["raw_data_dir"].joinpath(mode,device)
                df_ads = create_dataframe(raw_data_dir)
                df_ads = fillna_dropna(df_ads)
                df_ads = expand_dicts(df_ads)
                all_dfs.append(df_ads)

        df_final = pd.concat(all_dfs)
    else:
        raw_data_dir = CONF_LIST["save_dirs"]["raw_data_dir"]
        df_ads = create_dataframe(raw_data_dir)
        
        df_ads = fillna_dropna(df_ads)
        df_final = expand_dicts(df_ads)

    
    df_final = preprocess_df(df_final)
    cat_cols = select_cat_cols(df_final)
    df_final = encode_cat_cols(df_final,cat_cols)
    df_final = remove_outliers(df_final,CONF_LIST["target_variable"])
    non_cat_cols = select_non_cat_cols(df_final)
    df_final = erase_correlated_cols(df_final,non_cat_cols,0.95,CONF_LIST["target_variable"])
    class_cols = classify_cols(df_final)
    scaling_features = list(chain(*class_cols[1:]))
    scaler,df_final = scale(df_final,scaling_features)
    print("DF_FINAL_COLUMNS",df_final.columns)
    generate_dataset(df_final,class_cols,CONF_LIST)
    save_scaling_features(scaler,class_cols[1],scaling_features,CONF_LIST)


def clean_to_predict(df_final,model_directory):
    """
    Data path is the directory of .html files
    """
    # json_files = os.listdir(data_path)
    # dfs = []
    # for json_file in json_files:
    #     with open(json_file, 'r') as file:
    #         data = pd.read_json(file)
    #         dfs.append(data)
    # #Loading features and scaler to be applied
    # df_final = pd.concat(dfs, ignore_index=True)
    file_features = model_directory.joinpath("selected_features.json")
    file_scaler = model_directory.joinpath("scaler.joblib")
    file_headers = model_directory.joinpath("scaling_features.json")
    with open(file_features,'r') as f1,open(file_scaler,'rb') as f2, open(file_headers,'r') as f3:
        features = json.load(f1)
        scaler = joblib.load(f2) 
        scaling_features = json.load(f3)
    df_final.fillna(0,inplace=True)
    cat_cols = select_cat_cols(df_final)
    df_final = encode_cat_cols(df_final,cat_cols)
    df_final = fillna_dropna(df_final)
    try:
        df_final = df_final[features]
    except KeyError as e:
        str_traceback = str(e)
        # print("KEYERROR OBTAINED: THE FOLLOWING VARIABLES ARE MISSING")
        # print("THEY WILL BE FILLED AS ZEROS. PLEASE, SELECT THE VARIABLE")
        # print(str_traceback.split("'"))
        # index_from_traceback = int(input("Select index from tuple:"))
        df_final[str_traceback.split("'")[1:-1]] = 0
    #COLUMNS THAT ARE IN THE DF BUT NOT IN SCALING FEATURES 
    cols_to_drop = set(df_final.columns) - set(scaling_features)
    #COLUMNS THAT ARE IN SCALING FEATURES BUT NOT IN THE DF
    cols_to_fill =  set(scaling_features) - set(df_final.columns)
    
    # all_headers = []
    # for file in ("DataX.csv","DataY.csv"):
    #     headers = pd.read_csv(model_directory.joinpath(file), nrows=1).columns.tolist()
    #     all_headers += headers
    # print("COLUMNS THAT WE ARE INTRODUCING AS REFILL")
    # cols_refill = set(all_headers) - set(df_final.columns)
    # cols_erase = set(df_final.columns) - set(all_headers)
    df_final.drop(cols_to_drop,axis=1,inplace=True)
    for col in cols_to_fill:
        df_final[col] = 0

    df_final = df_final[scaling_features]
    #To prepare the final vector, find where are our actual features
    where_features = [scaling_features.index(item) for item in features]
    print(where_features)
    print("DO WE HAVE SAME FEATURES",set(df_final.columns) == set(scaling_features))
    print("PERFORM SCALING")
    df_final = scaler.transform(df_final)

    return df_final[:,where_features]








  