not_valid_landing_pages = [
  "github.com",
  "richaudience.com",
  "google.com",
  "google.es",
  "facebook.com",
  "twitter.com",
  "adsafeprotected.com",
  "cdn.exactag.com"
]
