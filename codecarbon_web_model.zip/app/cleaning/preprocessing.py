from collections import Counter
from itertools import chain
import json
import os
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder
from tqdm import tqdm



def remove_extra_fields(df):
    fields_to_remove = ['usedJSHeapSize', 'jsHeapSizeLimit', 'totalJSHeapSize','event_size']
    return df[[col for col in df.columns if col not in fields_to_remove]]

def load_data_files(data_path):
    source_file = pd.read_csv(data_path.joinpath("data_url.csv"))
    source_file = remove_extra_fields(source_file)
    source_file["entries"] = source_file["entries"].apply(lambda x:json.loads(x))
    source_file["performance"] = source_file["performance"].apply(lambda x:json.loads(x))
    return source_file




def treat_common(web):
    """
    Rename the common cols according to sub_url
    """
    print(web)
    COMMON_COLS = ["width","height","usedJSHeapSize","totalJSHeapSize","jsHeapSizeLimit","event_size"]
    web = web[COMMON_COLS]
    web.rename({col:f"{col}_{1}" for col in COMMON_COLS},inplace=True)
    return web 


def treat_entries(test_ad):
    """
    Preprocess the javascript entries dictionary
    """

    entries_dict = test_ad["entries"]
    if isinstance(entries_dict,str):
        return {}
    common_keys = set.intersection(*[set(entry.keys()) for entry in entries_dict])
    #print(common_keys)
    common_keys.remove("name")
    final_ad = dict()
    for k in common_keys:
        arr = [entries_dict[i][k] for i in range(len(entries_dict))]

        if type(arr[0]) == str:
            cat_count = Counter(arr)
            cat_dict = {(f"res_{k}"):v for k,v in dict(cat_count).items()}
            final_ad = {**final_ad,**cat_dict} 

        if type(arr[0]) == int or type(arr[0]) == float:
            cont_dict = {f"entries_avg_{k}":np.average(arr),
                         f"entries_median_{k}":np.median(arr),
                         f"entries_min_{k}":np.min(arr),
                         f"entries_max_{k}":np.max(arr),
                         f"entries_range_{k}":np.ptp(arr),
                         f"entries_std_{k}":np.std(arr)}
            final_ad = {**final_ad,**cont_dict}
    return final_ad

def treat_dict(test_ad):
    """
    Treat other dictionaries that may exist in JS
    """
    final_ad = {}
    for k in {key for key,val in test_ad.items() if type(val) == dict}:
        treated = {f"{str(k)}_{k1}":v1 for k1,v1  in test_ad[k].items()}
        final_ad = {**final_ad,**treated}
    return final_ad

def preprocess_df(df_ads):
    """
    Some cleaning operations, described in each step
    """
    #Erase columns with a single index not NaN
    df_ads = df_ads.drop(df_ads.describe().loc["std"].loc[lambda x: x == 0].index,axis=1)
    #Drop columns with all None values
    for col in df_ads.columns:
    #Erase the columns with all none values
        if df_ads.isnull().sum().loc[col] == df_ads.shape[0]:
            df_ads = df_ads.drop(col,axis=1)
    #Erase useless columns 
    banned_keywords = "timestamp","region","run_id","uuid","driver_url","project_name","country","on_cloud"
    banned_cols = [col for col in df_ads.columns  for word in banned_keywords if word in col]
    df_ads = df_ads.drop(banned_cols,axis=1)
    #Filling NaN values of perf.getEntries

    #df_ads.dropna(axis=1,inplace=True)


    return df_ads 

def select_cat_cols(df_ads):
    return list(df_ads.dtypes.loc[lambda x: x == object].index)

def select_non_cat_cols(df_ads):
    return list(set(df_ads.columns) - set(select_cat_cols(df_ads)))


def encode_cat_cols(df,cat_cols):
    print(cat_cols)
    encoder = OneHotEncoder(sparse_output=False).set_output(transform="pandas")
    cols_encoded = encoder.fit_transform(df[cat_cols])
    print("cols_encoded",cols_encoded.columns)
    df = df.drop(cat_cols,axis=1)
    return pd.concat([df,cols_encoded],axis=1)


def remove_outliers(df,col,factor=1.5):
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    limite_inferior = Q1 - factor * IQR
    limite_superior = Q3 + factor * IQR
    df_filtrado = df[(df[col] >= limite_inferior) & (df[col] <= limite_superior)].dropna()
    return df_filtrado


# def erase_correlated_cols(df_ads, target_cols, threshold, preferential_col):
#     print("Creating correlation matrix")
#     corr_matrix = df_ads.corr().abs()
#     print("Getting upper...")
#     upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
#     to_drop = []

#     for column in tqdm(target_cols):
#         if column == preferential_col:
#             continue  # No se elimina la columna preferencial

#         correlated_cols = upper[column][upper[column] > threshold].index.tolist()
#         if correlated_cols:
#             to_drop.append(column)  # Eliminar solo una de las columnas correlacionadas

#     df_ads.drop(to_drop, axis=1, inplace=True)
#     return df_ads

from tqdm import tqdm
import numpy as np

def erase_correlated_cols(df_ads, target_cols, threshold, preferential_col):
    """
    Recorre las columnas de target_cols y, para cada columna (excepto la preferencial),
    calcula la correlación con las columnas que vienen después. Si encuentra que la 
    correlación (valor absoluto) supera el umbral, elimina la columna actual.
    """
    to_drop = set()

    # Recorremos cada columna y comparamos solo con las que le siguen en el orden
    for i, col in enumerate(tqdm(target_cols)):
        if col == preferential_col:
            continue  # No se elimina la columna preferencial
        for other_col in target_cols[i+1:]:
            # Si ya se marcó para eliminar, saltamos la comparación
            if other_col in to_drop:
                continue
            corr_val = abs(df_ads[col].corr(df_ads[other_col]))
            if corr_val > threshold:
                to_drop.add(col)
                # Una vez que se encuentra una correlación alta, se elimina la columna actual
                break

    df_ads.drop(list(to_drop), axis=1, inplace=True)
    return df_ads




def scale(df_ads,cols_to_scale):
    df_ads = df_ads[cols_to_scale]
    sc = MinMaxScaler()
    df_standarized = pd.DataFrame(sc.fit_transform(df_ads),columns=df_ads.columns)
    return sc,df_standarized



def classify_cols(df_ads):
    features = ['duration', 'emissions', 'emissions_rate', 'cpu_power', 'ram_power', 'cpu_energy', 'ram_energy', 'energy_consumed', 'os', 'python_version', 'codecarbon_version', 'cpu_count', 'cpu_model', 'longitude', 'latitude', 'ram_total_size', 'tracking_mode','dominion']
    non_study_cols = [item for item in df_ads.columns for word in features if word in item]
    for item in non_study_cols:
        print(item)
    exceptions = [item for item in non_study_cols if "duration" in item and "entries" in item ]
    non_study_cols = [item for item in non_study_cols if item not in exceptions]
    non_study_cols.append("timeOrigin")
    labels = [col for col in df_ads.columns if not('dominion' in col) and ("energy" in col or "emission" in col)]
    study_cols = list(set(df_ads.columns) - set(non_study_cols) - set(labels))

    
    return non_study_cols,study_cols,labels

def describe_suburls(df_ads):
    digit_columns = df_ads.filter(regex='\d$', axis=1)
    all_dfs = []
    for item in set([col[:-2] for col in  digit_columns.columns]):
        filtered_columns = digit_columns.filter(like=item, axis=1)
        described_columns = filtered_columns.T.describe().T
        described_columns = described_columns.add_prefix(item+"_",axis=1)
        all_dfs.append(described_columns)
    final_df = pd.concat(all_dfs,axis=1)
    final_df.dropna(axis=1) 

    df_ads = df_ads.drop(digit_columns,axis=1) 
    df_ads = pd.concat([df_ads,final_df],axis=1)

    return df_ads
    

def save(df_ads,OUTPUT_FILENAME):
    df_ads.to_csv(OUTPUT_FILENAME,index=False)



def generate_dataset(df_ads,class_cols,CONF_LIST):
    save_path = CONF_LIST["save_dirs"]["clean_data_dir"].joinpath(CONF_LIST["name"])
    names = ["DataX_temp","DataY_temp"]
    if not os.path.exists(save_path):
        os.makedirs(save_path)
        names = ["DataX","DataY"]
    for i,name in enumerate(names):
        save(df_ads[[col for col in df_ads.columns if col in class_cols[i]]],str(save_path)+f"/{name}.csv")

def fillna_dropna(df, threshold=0.25, fill_value="Unknown"):
    """
    Fill NaNs with 'Unknown' for string columns with up to 25% NaNs
    and fill NaNs with mean for other columns with up to 25% NaNs.
    Drop columns with more than 25% NaNs.

    Parameters:
    - df: DataFrame
    - threshold: Threshold to decide whether to fill or drop columns (default is 0.25)
    - fill_value: Value to fill NaNs in string columns (default is 'Unknown')

    Returns:
    - df: Modified DataFrame
    """
    if df.isnull().sum().sum() == 0:
        return df

    # Identify columns with string dtype
    string_columns = df.select_dtypes(include=['object']).columns

    # Calculate the proportion of NaNs per column
    nan_proportions = (df.isnull().sum() / len(df)).sort_values()

    # Filter columns to fill or drop
    columns_to_fill = nan_proportions[nan_proportions <= threshold].index
    columns_to_drop = nan_proportions[nan_proportions > threshold].index
    # print("COLUMNS TO FILL")
    # print(columns_to_fill)
    # print("COLUMNS TO DROP")
    # print(columns_to_drop)

    # Fill NaNs with 'Unknown' for selected string columns
    # Fill NaNs with mean for other columns
    for column in columns_to_fill:
        if column in string_columns:
            df[column] = df[column].fillna(fill_value)
        else:
            df[column] = df[column].fillna(df[column].mean())

    # Drop columns with more than 25% NaNs
    df = df.drop(columns=columns_to_drop)

    return df

def save_scaling_features(scaler,features,scaling_features,CONF_LIST):
    save_path = CONF_LIST["save_dirs"]["model_dir"].joinpath(CONF_LIST["name"],"scaler")
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    suf = "_temp"  if "scaler.joblib" in os.listdir(save_path) else ""
    joblib.dump(scaler, save_path.joinpath(f'scaler{suf}.joblib'))
    with open(save_path.joinpath(f'selected_features{suf}.json'), 'w') as json_file:
            json.dump(features, json_file) 
    with open(save_path.joinpath(f'scaling_features{suf}.json'), 'w') as json_file:
            json.dump(scaling_features, json_file)

#--------------------------------------




def clean_data(CONF_LIST):
    print("start clean data")
    all_dfs = []
    for device in CONF_LIST["list_devices"]:
        print(f"Cleaning data for device {device}")

        raw_data_dir = CONF_LIST["save_dirs"]["raw_data_dir"].joinpath(device)
        print(f"Loading data files from {device}")
        source_df = load_data_files(raw_data_dir)
        source_df = fillna_dropna(source_df)
        #JUST INCLUDE IN THE DOMINION VERSION
        url_dicts = []
        final_web_dict = {}
        
        for i,web in tqdm(source_df.iterrows(),desc="Treating entries..."):
            #common_web = treat_common(web)
            entries_web = treat_entries(web)
            dict_web = treat_dict(web)
            dict_web = treat_dict(dict_web)

            final_web_dict = {**final_web_dict,**entries_web,**dict_web}
            url_dicts.append(final_web_dict)
        df_webs = pd.DataFrame(url_dicts)
        df_webs.fillna(0,inplace=True)
        df_webs = fillna_dropna(df_webs)
        #Treat information for each suburl
        
        
        #This is just for dominions, as it plans to aggregate the sub_urls
        #df_webs = describe_suburls(df_webs)
        final_df = pd.concat([source_df,df_webs],axis=1)
        final_df.drop(["performance","entries"],axis=1,inplace=True)
        all_dfs.append(final_df)
    print(f"Dataframe created  {final_df.shape}")
    final_df = pd.concat(all_dfs)
    print(f"Preprocessing initiated  {final_df.shape}")
    final_df = preprocess_df(final_df)
    print(final_df.shape)
    cat_cols = select_cat_cols(final_df)
    non_cat_cols = select_non_cat_cols(final_df)
    print("Erasing correlated columnas")
    final_df = erase_correlated_cols(final_df,non_cat_cols,0.95,CONF_LIST["target_variable"])
    print(final_df.shape)
    final_df = encode_cat_cols(final_df,cat_cols)
    print(f"Removing outliers  {final_df.shape}")
    final_df = remove_outliers(final_df,CONF_LIST["target_variable"])
    print("Classifying columns")
    _,study_cols,labels = classify_cols(final_df)
    scaling_features = list(chain(study_cols,labels))
    final_df = final_df[scaling_features]
    

    print("Scaling features",final_df.shape)
    scaler,final_df = scale(final_df,final_df.columns)
    print("Genrating dataset",final_df.shape)
    final_df.to_csv("final_df.csv")
    generate_dataset(final_df,[study_cols,labels],CONF_LIST)
    print("Saving")
    save_scaling_features(scaler,study_cols,scaling_features,CONF_LIST)

def clean_to_predict(df_final,data_directory):
    file_features = data_directory.joinpath("selected_features.json")
    file_scaler = data_directory.joinpath("scaler.joblib")
    file_headers = data_directory.joinpath("scaling_features.json")
    with open(file_features,'r') as f1,open(file_scaler,'rb') as f2, open(file_headers,'r') as f3:
        features = json.load(f1)
        scaler = joblib.load(f2) 
        scaling_features = json.load(f3)


    url_dicts = []
    final_web_dict = {}
    
    for i,web in df_final.iterrows():
        #common_web = treat_common(web)
        entries_web = treat_entries(web)
        dict_web = treat_dict(web)
        dict_web = treat_dict(dict_web)

        final_web_dict = {**final_web_dict,**entries_web,**dict_web}
        url_dicts.append(final_web_dict)
    df_webs = pd.DataFrame(url_dicts)
    df_webs.to_csv("test.csv")
    df_webs = df_webs.fillna(0)

    final_df = pd.concat([df_final,df_webs],axis=1)
    final_df.drop(["performance","entries"],axis=1,inplace=True)

    cat_cols = select_cat_cols(final_df)
    df_webs = encode_cat_cols(final_df,cat_cols)
    
    try:
        final_df = final_df[features]
    except KeyError as e:
        str_traceback = str(e)
        print(str_traceback)
        print("KEYERROR OBTAINED: THE FOLLOWING VARIABLES ARE MISSING")
        print("THEY WILL BE FILLED AS ZEROS. PLEASE, SELECT THE VARIABLE")
        df_final[str_traceback.split("'")[1:-1]] = 0
    #COLUMNS THAT ARE IN THE DF BUT NOT IN SCALING FEATURES 
    cols_to_drop = set(final_df.columns) - set(scaling_features)
    #COLUMNS THAT ARE IN SCALING FEATURES BUT NOT IN THE DF
    cols_to_fill =  set(scaling_features) - set(final_df.columns)

    # all_headers = []
    # for file in ("DataX.csv","DataY.csv"):
    #     headers = pd.read_csv(model_directory.joinpath(file), nrows=1).columns.tolist()
    #     all_headers += headers
    # print("COLUMNS THAT WE ARE INTRODUCING AS REFILL")
    # cols_refill = set(all_headers) - set(df_final.columns)
    # cols_erase = set(df_final.columns) - set(all_headers)
    final_df.drop(cols_to_drop,axis=1,inplace=True)
    for col in cols_to_fill:
        final_df[col] = 0

    final_df = final_df[scaling_features]
    #To prepare the final vector, find where are our actual features
    where_features = [scaling_features.index(item) for item in features]
    print(where_features)
    print("DO WE HAVE SAME FEATURES",set(final_df.columns) == set(scaling_features))
    print("PERFORM SCALING")
    final_df = scaler.transform(final_df)

    return final_df[:,where_features]


